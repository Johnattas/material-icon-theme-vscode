# Changelog

## v1.16.2

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.16.1...v1.16.2)

## v1.16.1

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.16.0...v1.16.1)

### 🩹 Fixes

- Improve extension with tests and fixes ([#149](https://github.com/material-extensions/material-icons-browser-extension/pull/149))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))

## v1.16.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.15.0...v1.16.0)

### 🚀 Enhancements

- Support auto-i18n for AMO links ([#146](https://github.com/material-extensions/material-icons-browser-extension/pull/146))

### 🩹 Fixes

- Conflict with Refined GitHub ([#148](https://github.com/material-extensions/material-icons-browser-extension/pull/148))

### ❤️ Contributors

- Fregante ([@fregante](https://github.com/fregante))
- Gitoffthelawn ([@Gitoffthelawn](https://github.com/Gitoffthelawn))

## v1.15.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.14.1...v1.15.0)

### 🚀 Enhancements

- Remove language id build process ([#145](https://github.com/material-extensions/material-icons-browser-extension/pull/145))
- Add Firefox Android support ([#144](https://github.com/material-extensions/material-icons-browser-extension/pull/144))
- Improve release workflow ([5e78321](https://github.com/material-extensions/material-icons-browser-extension/commit/5e78321))

### 🩹 Fixes

- Skip copying semantic icon classes to avoid RGH conflict ([#143](https://github.com/material-extensions/material-icons-browser-extension/pull/143))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))

## v1.14.1

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.14.0...v1.14.1)

## v1.14.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.13.1...v1.14.0)

### 🚀 Enhancements

- Add tangled support ([#141](https://github.com/material-extensions/material-icons-browser-extension/pull/141))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))

## v1.13.1

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.13.0...v1.13.1)

## v1.13.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.12.0...v1.13.0)

### 🚀 Enhancements

- Enhance "Files Changed" experience ([#137](https://github.com/material-extensions/material-icons-browser-extension/pull/137))

### ❤️ Contributors

- Chillcicada ([@chillcicada](https://github.com/chillcicada))

## v1.12.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.11.0...v1.12.0)

### 🚀 Enhancements

- Support GitHub's improved pull request "Files Changed" experience ([#135](https://github.com/material-extensions/material-icons-browser-extension/pull/135))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))

## v1.11.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.9...v1.11.0)

### 🚀 Enhancements

- Add support for forgejo ([#132](https://github.com/material-extensions/material-icons-browser-extension/pull/132))
- Enhance footer component to display version information ([f8c0ced](https://github.com/material-extensions/material-icons-browser-extension/commit/f8c0ced))

### 🩹 Fixes

- Update getIsSymlink method to use class check for symlink icon (Closes #133) ([#133](https://github.com/material-extensions/material-icons-browser-extension/issues/133))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))
- WitnessMee

## v1.10.9

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.8...v1.10.9)

## v1.10.8

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.7...v1.10.8)

## v1.10.7

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.6...v1.10.7)

## v1.10.6

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.5...v1.10.6)

### 🩹 Fixes

- Missing icons on Github Actions and Workflows ([#125](https://github.com/material-extensions/material-icons-browser-extension/pull/125))
- Update contributor link in changelog ([37f4215](https://github.com/material-extensions/material-icons-browser-extension/commit/37f4215))
- Add missing icon for file-diff in GitHub provider ([#127](https://github.com/material-extensions/material-icons-browser-extension/pull/127))

### 🏡 Chore

- Update dependencies ([a14b7d7](https://github.com/material-extensions/material-icons-browser-extension/commit/a14b7d7))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))
- Yen Cheng Lin

## v1.10.5

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.4...v1.10.5)

## v1.10.4

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.3...v1.10.4)

## v1.10.3

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.2...v1.10.3)

## v1.10.2

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.1...v1.10.2)

## v1.10.1

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.10.0...v1.10.1)

### 🩹 Fixes

- **ci:** Use Microsoft Edge Add-ons API v1.1 ([ea8e5eb](https://github.com/material-extensions/material-icons-browser-extension/commit/ea8e5eb))
- **ci:** Pr title workflow should be executed on updates ([bb1c2c5](https://github.com/material-extensions/material-icons-browser-extension/commit/bb1c2c5))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))

## v1.10.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.9.0...v1.10.0)

### 🚀 Enhancements

- Update release workflow to use a preparation step ([061515a](https://github.com/material-extensions/material-icons-browser-extension/commit/061515a))
- Update icons ([0e01e40](https://github.com/material-extensions/material-icons-browser-extension/commit/0e01e40))
- **ci:** Update release process ([ebc3fed](https://github.com/material-extensions/material-icons-browser-extension/commit/ebc3fed))

### 🩹 Fixes

- **ci:** Fetch whole history to generate proper changelog ([408a51c](https://github.com/material-extensions/material-icons-browser-extension/commit/408a51c))
- Update changelog ([ff555f5](https://github.com/material-extensions/material-icons-browser-extension/commit/ff555f5))
- Remove outdated badge from readme ([eccdc9f](https://github.com/material-extensions/material-icons-browser-extension/commit/eccdc9f))
- Update readme description ([cfa3e83](https://github.com/material-extensions/material-icons-browser-extension/commit/cfa3e83))
- Update package-lock.json ([faeefdd](https://github.com/material-extensions/material-icons-browser-extension/commit/faeefdd))
- Custom GitLab domain on Firefox ([#121](https://github.com/material-extensions/material-icons-browser-extension/pull/121))
- **ci:** Update release process ([b7c65e6](https://github.com/material-extensions/material-icons-browser-extension/commit/b7c65e6))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))

## v1.8.33...v1.9.0

[compare changes](https://github.com/material-extensions/material-icons-browser-extension/compare/v1.8.33...v1.9.0)

### 🚀 Enhancements

- Update release workflow ([adf9b9d](https://github.com/material-extensions/material-icons-browser-extension/commit/adf9b9d))

### 🩹 Fixes

- Icon sizes other than medium work randomly ([#119](https://github.com/material-extensions/material-icons-browser-extension/pull/119))
- Update selectors for Gitea provider ([#120](https://github.com/material-extensions/material-icons-browser-extension/pull/120))
- **ci:** Update pr title workflow ([8363871](https://github.com/material-extensions/material-icons-browser-extension/commit/8363871))
- **ci:** Update pr closed workflow ([a619540](https://github.com/material-extensions/material-icons-browser-extension/commit/a619540))
- Update URL in comment ([e19b65d](https://github.com/material-extensions/material-icons-browser-extension/commit/e19b65d))

### 🏡 Chore

- **workflows:** Use app token in workflows ([7037529](https://github.com/material-extensions/material-icons-browser-extension/commit/7037529))
- **workflows:** Update workflows ([4f829af](https://github.com/material-extensions/material-icons-browser-extension/commit/4f829af))
- Create devcontainer.json ([#110](https://github.com/material-extensions/material-icons-browser-extension/pull/110))

### ❤️ Contributors

- Philipp Kief ([@PKief](https://github.com/PKief))
- Black-backdoor ([@black-backdoor](https://github.com/black-backdoor))
- Pham Minh Triet ([@Nanome203](https://github.com/Nanome203))
- Hema203 ([@Hema203](https://github.com/hema203))
